# Themes
## Office 2010
### DWM
#### Silver
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver.png)
#### Backstage
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Siver%20-%20Backstage.png)
#### Black
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Black.png)
#### Backstage
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Black%20-%20Backstage.png)
#### Blue
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Blue.png)
#### Backstage
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Blue%20-%20Backstage.png)
### Non DWM
#### Silver
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20Non%20DWM.png)
#### Black
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Black%20-%20Non%20DWM.png)

## Office 2013
### DWM
#### White
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202013%20-%20White.png)
##### Backstage
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202013%20-%20White%20-%20Backstage.png)

## Windows 8
### DWM
#### White
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Windows%208%20-%20White.png)
##### Backstage
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Windows%208%20-%20White%20-%20Backstage.png)

# Controls
## Backstage
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20Backstage.png)
## Gallery
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20Gallery.png)
## Filter in Gallery
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20Filter%20in%20Gallery.png)
## ColorGallery
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20ColorGallery.png)
## Gallery in QuickAccess
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20Gallery%20in%20QuickAccess.png)
## ComboBox in QuickAccess
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20ComboBox%20in%20QuickAccess.png)

# Misc
## Right-to-left
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20RTL.png)
## Collapsed Group
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20Collapsed%20Group.png)
## KeyTips
![](https://github.com/fluentribbon/Fluent.Ribbon/raw/master/Images/Screenshots/Office%202010%20-%20Silver%20-%20KeyTips.png)